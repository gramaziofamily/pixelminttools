import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: { mint: '#10b981', deep: '#071126', softmint: '#ecfdf5' },
      borderRadius: { '3xl': '1.75rem' }
    },
  },
  plugins: [],
};
export default config;
