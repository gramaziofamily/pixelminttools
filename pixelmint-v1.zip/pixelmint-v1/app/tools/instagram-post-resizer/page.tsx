'use client';

import { useRef, useState } from 'react';

export default function InstagramPostResizer() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [downloadUrl, setDownloadUrl] = useState('');
  const [preset, setPreset] = useState('1080x1080');

  async function handleFile(file: File) {
    const [w,h] = preset.split('x').map(Number);
    const img = new Image();
    img.onload = () => {
      const canvas = canvasRef.current!;
      canvas.width = w; canvas.height = h;
      const ctx = canvas.getContext('2d')!;
      ctx.fillStyle = '#ffffff'; ctx.fillRect(0,0,w,h);
      const scale = Math.max(w / img.width, h / img.height);
      const sw = img.width * scale, sh = img.height * scale;
      ctx.drawImage(img, (w - sw)/2, (h - sh)/2, sw, sh);
      setDownloadUrl(canvas.toDataURL('image/png'));
    };
    img.src = URL.createObjectURL(file);
  }

  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <a href="/" className="font-bold text-mint">← PixelMint</a>
      <h1 className="mt-8 text-5xl font-black">Instagram Post Resizer</h1>
      <p className="mt-4 text-xl text-slate-600">Resize images for Instagram posts in seconds. Free, no signup, no watermarks.</p>

      <div className="mt-8 rounded-3xl border p-8 card-shadow">
        <label className="font-bold">Choose size</label>
        <select className="ml-4 rounded-xl border p-3" value={preset} onChange={e=>setPreset(e.target.value)}>
          <option value="1080x1080">Square Post — 1080 × 1080</option>
          <option value="1080x1350">Portrait Post — 1080 × 1350</option>
          <option value="1080x566">Landscape Post — 1080 × 566</option>
          <option value="1080x1920">Story/Reel — 1080 × 1920</option>
        </select>

        <input className="mt-8 block w-full rounded-xl border p-4" type="file" accept="image/*" onChange={e=>e.target.files?.[0] && handleFile(e.target.files[0])}/>
        <canvas ref={canvasRef} className="mt-8 max-h-[500px] max-w-full rounded-xl border bg-white"></canvas>
        {downloadUrl && <a download="pixelmint-instagram-resized.png" href={downloadUrl} className="mt-6 inline-block rounded-xl bg-mint px-8 py-4 font-bold text-white">Download Image</a>}
      </div>

      <section className="mt-12 leading-8">
        <h2 className="text-3xl font-black">Best Instagram post sizes</h2>
        <p className="mt-3">Use 1080 × 1080 for square posts, 1080 × 1350 for portrait posts, and 1080 × 566 for landscape posts.</p>
        <h2 className="mt-8 text-3xl font-black">Is this free?</h2>
        <p className="mt-3">Yes. PixelMint is free, requires no account, and does not add watermarks.</p>
      </section>
    </main>
  );
}
