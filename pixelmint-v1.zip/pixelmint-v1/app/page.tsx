import Link from 'next/link';
import { Gift, Zap, ShieldCheck, Heart, CheckCircle, Upload, Download, Sparkles } from 'lucide-react';

const tools = [
  ['Instagram Post Resizer','Resize images for Instagram posts in seconds.','📸','/tools/instagram-post-resizer'],
  ['YouTube Thumbnail Resizer','Create the perfect YouTube thumbnails every time.','▶️','#'],
  ['Discord Emoji Resizer','Resize Discord emojis to the perfect dimensions.','💬','#'],
  ['Facebook Cover Resizer','Resize Facebook cover photos with the right dimensions.','f','#'],
  ['Etsy Banner Resizer','Optimize your Etsy shop banner for a professional look.','E','#'],
  ['Image Compressor','Compress images without losing quality.','🖼️','#'],
  ['JPG to PNG','Convert JPG images to high-quality PNG.','JPG','#'],
  ['PNG to JPG','Convert PNG images to high-quality JPG.','PNG','#'],
];

export default function Home() {
  return (
    <main>
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <div className="flex items-center gap-3 text-3xl font-black"><span className="rounded-xl bg-mint p-2 text-white">🌿</span>Pixel<span className="text-mint">Mint</span><Sparkles className="text-mint" /></div>
        <div className="hidden gap-10 font-semibold md:flex"><a>Home</a><a>Image Tools</a><a>Social Media Sizes</a><a>Guides</a><a>Blog</a></div>
        <button className="rounded-2xl bg-mint px-7 py-4 font-bold text-white">All Tools</button>
      </nav>

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-8 md:grid-cols-2">
        <div>
          <h1 className="text-6xl font-black leading-tight md:text-7xl">Resize <span className="text-mint">Smarter.</span></h1>
          <h2 className="mt-4 text-3xl font-black">Fast tools for perfect images.</h2>
          <p className="mt-6 max-w-xl text-xl leading-relaxed text-slate-600">Resize photos for Instagram, YouTube, Facebook, Discord, Etsy, and more in seconds.</p>
          <div className="mt-8 flex gap-4">
            <Link href="/tools/instagram-post-resizer" className="rounded-2xl bg-mint px-8 py-4 font-bold text-white shadow-lg"><Upload className="mr-2 inline" size={18}/>Upload Image</Link>
            <a className="rounded-2xl border-2 border-mint px-8 py-4 font-bold text-mint">Browse Tools ✨</a>
          </div>
          <div className="mt-9 grid grid-cols-3 gap-5 text-sm">
            <div><Zap className="inline rounded-full bg-softmint p-1 text-mint"/> <b>Fast</b><br/><span className="text-xs text-slate-500">Instant processing</span></div>
            <div><ShieldCheck className="inline rounded-full bg-softmint p-1 text-mint"/> <b>Secure</b><br/><span className="text-xs text-slate-500">Images stay private</span></div>
            <div>📱 <b>Mobile</b><br/><span className="text-xs text-slate-500">Works on any device</span></div>
          </div>
        </div>

        <div className="card-shadow rounded-3xl bg-white p-8">
          <div className="grid grid-cols-2 gap-8">
            <div><b>Before</b><div className="mt-3 h-44 rounded-xl border-4 border-mint bg-gradient-to-br from-emerald-100 to-slate-300"></div></div>
            <div><b>After</b><div className="mt-3 h-44 rounded-xl bg-gradient-to-br from-emerald-100 to-slate-300"></div></div>
          </div>
          <div className="mt-7 rounded-xl border p-4"><b>Resize for</b> &nbsp; Instagram Post (1080 × 1080)</div>
          <button className="mt-7 w-full rounded-xl bg-mint py-4 font-bold text-white"><Download className="mr-2 inline" size={18}/>Download Image</button>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6">
        <div className="rounded-3xl border-2 border-mint bg-gradient-to-r from-softmint to-white p-8">
          <div className="grid items-center gap-6 md:grid-cols-[220px_1fr_360px]">
            <div className="text-8xl">🛡️</div>
            <div>
              <div className="text-5xl font-black">ALWAYS FREE.</div>
              <div className="script mt-2 text-4xl font-bold">Never any sign up.</div>
            </div>
            <div className="space-y-3 text-xl font-bold">
              <p>✅ 100% Free Forever</p><p>✅ Never Any Sign Up</p><p>✅ No Hidden Fees</p><p>✅ No Watermarks</p>
              <p className="script text-right text-3xl text-mint">We promise! ♡</p>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-12 text-center">
        <p className="font-bold text-mint">⭐ POPULAR TOOLS</p>
        <h2 className="text-4xl font-black">Popular Image Tools</h2>
        <p className="mt-2 text-slate-600">The most used tools by creators and businesses.</p>
        <div className="mt-8 grid gap-5 md:grid-cols-4">
          {tools.map(([title,desc,icon,href]) => (
            <Link href={href} key={title} className="rounded-2xl border bg-white p-8 card-shadow">
              <div className="text-5xl">{icon}</div><h3 className="mt-5 text-xl font-black">{title}</h3><p className="mt-2 text-sm text-slate-600">{desc}</p><p className="mt-4 font-bold text-mint">Open Tool →</p>
            </Link>
          ))}
        </div>
      </section>
    </main>
  );
}
