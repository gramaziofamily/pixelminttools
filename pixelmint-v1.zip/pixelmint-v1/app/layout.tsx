import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'PixelMint — Resize Smarter',
  description: 'Fast, free image tools. No signup. No watermarks.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
